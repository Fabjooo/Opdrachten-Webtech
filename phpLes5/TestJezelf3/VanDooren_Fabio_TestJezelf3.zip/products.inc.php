<?php 

    $products = [
        ["Name" => "HEX TIE HONEYCOMB SPACE BLACK", "Foto" => "http://cdn.shopify.com/s/files/1/0805/4507/products/Hextie3_1024x1024.jpg?v=1445439754", "Price" => "$99,99"], 
        ["Name" => "HEX TIE BLACK DIAMOND", "Foto" => "http://cdn.shopify.com/s/files/1/0805/4507/products/FB_HBD_plain_1024x1024.jpg?v=1453938423", "Price" => "$119,99"],
        ["Name" => "HEX TIE LINES SPACE BLACK", "Foto" => "http://cdn.shopify.com/s/files/1/0805/4507/products/Hextie_1024x1024.jpg?v=1445439726", "Price" => "$90,00"]
        
    ];
    /*$id = $_GET['id'];
    $product = $products[$id];*/
?>